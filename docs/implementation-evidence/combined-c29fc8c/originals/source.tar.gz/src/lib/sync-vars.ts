import prisma from "./db";
import fs from "fs/promises";
import path from "path";
import { listAliases } from "./secret-references";
import { isSensitiveVariable } from "./variable-policy";
import { SecretError } from "./cluster-secrets";

const ANSIBLE_DIR = path.resolve(process.cwd(), "../ansible-playbook");
const VARS_FILE = path.join(ANSIBLE_DIR, "group_vars/all.yml");

// Template header for generated all.yml
const YAML_HEADER = `# Kubernetes Cluster Configuration Variables
# Auto-generated from Botrus K8s DB
# Last synced: ${new Date().toISOString()}
# WARNING: Manual edits to this file will be overwritten on next deploy/sync.

---
`;

/**
 * Read all variables from the database and write them to group_vars/all.yml.
 * Variables are grouped by category, with category headers as comments.
 */
export async function syncVarsToYAML(): Promise<{
  synced: number;
  file: string;
}> {
  const vars = await prisma.variable.findMany({
    orderBy: [{ category: "asc" }, { key: "asc" }],
  });

  const aliases = await listAliases();
  const safeVars = vars.filter((v) => !isSensitiveVariable(v));
  for (const ref of aliases) {
    if (safeVars.some((v) => v.key === ref.alias))
      throw new SecretError(409, "Alias collides with nonsecret configuration");
  }
  // Only valid Ansible identifiers are emitted; path-style aliases remain available to direct lookup.
  const refs = aliases.filter((ref) =>
    /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(ref.alias),
  );
  const emitted = [
    ...safeVars,
    ...refs.map((ref) => ({ key: ref.alias, category: "secret" })),
  ];
  if (
    emitted.some(
      (v) =>
        !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(v.key) ||
        !/^[a-zA-Z0-9_-]+$/.test(v.category),
    )
  )
    throw new SecretError(400, "Unsafe Ansible identifier or category");
  // Group by category
  const groups = new Map<string, typeof emitted>();
  for (const v of emitted) {
    const cat = v.category || "general";
    if (!groups.has(cat)) groups.set(cat, []);
    groups.get(cat)!.push(v);
  }

  // Build YAML
  const lines: string[] = [YAML_HEADER];

  for (const [category, items] of groups) {
    lines.push(
      `# =============================================================================`,
    );
    lines.push(`# ${category.toUpperCase()}`);
    lines.push(
      `# =============================================================================`,
    );
    for (const item of items) {
      // ALL variables are pulled from Botrus at Ansible runtime via lookup plugin.
      // Zero values ever touch the filesystem — all.yml is just a manifest of keys.
      lines.push(`${item.key}: "{{ lookup('botrus_secret', '${item.key}') }}"`);
    }
    lines.push("");
  }

  const yamlContent = lines.join("\n") + "\n";

  // Ensure directory exists
  await fs.mkdir(path.dirname(VARS_FILE), { recursive: true });

  // Write file
  await fs.writeFile(VARS_FILE, yamlContent, "utf8");

  console.log(
    `[sync-vars] Synced ${emitted.length} references to ${VARS_FILE}`,
  );

  return { synced: emitted.length, file: VARS_FILE };
}

/**
 * Parse node variables (category: kubernetes) and upsert into the Node table.
 * Pattern: node_<key>_<field> where field ∈ {name, hostname, ip, role}
 *   name     = user-chosen display name (e.g. "Living Room Server")
 *   hostname = actual machine hostname (e.g. "u1", "node-01")
 *   ip       = IP address for Ansible inventory
 *   role     = master | worker
 */
export async function syncNodesFromVars(): Promise<{ synced: number }> {
  const nodeVars = await prisma.variable.findMany({
    where: { category: "kubernetes", key: { startsWith: "node_" } },
    orderBy: { key: "asc" },
  });

  // Group by key: node_1_name, node_1_hostname, node_1_ip, node_1_role → group "1"
  const groups = new Map<
    string,
    { name?: string; hostname?: string; ip?: string; role?: string }
  >();
  const re = /^node_(.+)_(name|hostname|ip|role)$/;

  for (const v of nodeVars) {
    const m = v.key.match(re);
    if (!m) continue;
    const [, key, field] = m;
    if (!groups.has(key)) groups.set(key, {});
    const g = groups.get(key)!;
    if (field === "name") g.name = v.value;
    else if (field === "hostname") g.hostname = v.value;
    else if (field === "ip") g.ip = v.value;
    else if (field === "role") g.role = v.value;
  }

  let count = 0;
  for (const [, data] of groups) {
    if (!data.hostname || !data.ip) continue; // need at least hostname + IP
    await prisma.node.upsert({
      where: { hostname: data.hostname },
      update: {
        name: data.name || data.hostname,
        ipAddress: data.ip,
        role: data.role || "worker",
      },
      create: {
        name: data.name || data.hostname,
        hostname: data.hostname,
        ipAddress: data.ip,
        role: data.role || "worker",
        status: "pending",
      },
    });
    count++;
  }

  console.log(`[sync-nodes] Synced ${count} nodes from vars`);
  return { synced: count };
}

/**
 * Sync inventory from Node table to production.ini
 */
export async function syncInventoryToFile(): Promise<{
  synced: number;
  file: string;
}> {
  const nodes = await prisma.node.findMany({
    where: { status: { not: "error" } },
  });

  const masters = nodes.filter((n) => n.role === "master");
  const workers = nodes.filter((n) => n.role === "worker");

  const lines: string[] = [
    "# Kubernetes Cluster Inventory",
    `# Auto-generated by Botrus K8s`,
    `# Last synced: ${new Date().toISOString()}`,
    "",
    "[all]",
  ];

  for (const node of nodes) {
    lines.push(
      `${node.hostname} ansible_host=${node.ipAddress} ansible_user=brajam ansible_python_interpreter=/usr/bin/python3`,
    );
  }

  if (masters.length > 0) {
    lines.push("");
    lines.push("[master]");
    masters.forEach((n) => lines.push(n.hostname));
  }

  if (workers.length > 0) {
    lines.push("");
    lines.push("[worker]");
    workers.forEach((n) => lines.push(n.hostname));
  }

  lines.push("");
  lines.push("[k8s_nodes]");
  nodes.forEach((n) => lines.push(n.hostname));

  // Read SSH key from DB, fall back to default
  let sshKey = "/home/brajam/.ssh/id_ed25519";
  try {
    const keyVar = await prisma.variable.findUnique({
      where: { key: "ansible_ssh_private_key_file" },
    });
    if (keyVar?.value) sshKey = keyVar.value;
  } catch {
    /* use default */
  }

  lines.push("");
  lines.push("[all:vars]");
  lines.push("ansible_connection=ssh");
  lines.push(`ansible_ssh_private_key_file=${sshKey}`);
  lines.push("ansible_ssh_common_args='-o StrictHostKeyChecking=no'");

  const inventoryFile = path.join(ANSIBLE_DIR, "inventory/production.ini");
  await fs.mkdir(path.dirname(inventoryFile), { recursive: true });
  await fs.writeFile(inventoryFile, lines.join("\n") + "\n", "utf8");

  console.log(
    `[sync-inventory] Synced ${nodes.length} nodes to ${inventoryFile}`,
  );

  return { synced: nodes.length, file: inventoryFile };
}
