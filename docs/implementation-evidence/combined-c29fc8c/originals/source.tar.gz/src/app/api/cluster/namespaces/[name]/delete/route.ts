import { validateNamespace } from "@/lib/k8s";
import { clusterRoute } from "@/lib/cluster-http";
import { NextRequest, NextResponse } from "next/server";
import { kubectlExec } from "@/lib/k8s";
import { invalidateCache } from "@/lib/cluster-cache";
import { requireOperator } from "@/lib/permissions";
export async function DELETE(_request: NextRequest, { params }: {
    params: Promise<{
        name: string;
    }>;
}) {
    return clusterRoute(async () => {
        const auth = await requireOperator();
        if (auth instanceof NextResponse)
            return auth;
        const { name: rawName } = await params;
        const name = validateNamespace(rawName);
        const result = await kubectlExec(["delete", "namespace", name, "--wait=false"], 15000);
        invalidateCache();
        return NextResponse.json({ success: true });
    });
}
