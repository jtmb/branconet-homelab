"use client";
import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { RESOURCE_CAPABILITIES, resourceBase, ResourceType } from "@/lib/resource-capabilities";
import { requestJson, refetchCluster, useSession } from "@/lib/use-query";
import { openShell } from "@/lib/shell-manager";
import ConfirmDialog from "./confirm-dialog";
export type { ResourceType } from "@/lib/resource-capabilities";

const YamlModal = dynamic(() => import("./yaml-modal"), { ssr: false });
const LogModal = dynamic(() => import("./log-modal"), { ssr: false });
type Resource = { metadata?: { namespace?: string; name?: string }; name?: string; namespace?: string;
  spec?: { replicas?: number; paused?: boolean; unschedulable?: boolean; containers?: { name?: string }[];
    initContainers?: { name?: string }[]; ephemeralContainers?: { name?: string }[] }; desiredReplicas?: number; replicas?: number; paused?: boolean };
export interface ResourceActionProps { resourceType: ResourceType; resource: Resource; onAction?: () => void; initialOpen?: boolean }
interface Confirmation { title: string; message: string; label: string; name?: string; execute: (signal: AbortSignal) => Promise<void> }
export default function ResourceActionsMenu({ resourceType, resource, onAction, initialOpen = false }: ResourceActionProps) {
  const session = useSession();
  const capability = RESOURCE_CAPABILITIES[resourceType];
  const name = resource.metadata?.name ?? resource.name ?? "";
  const namespace = resource.metadata?.namespace ?? resource.namespace ?? "";
  const base = resourceBase(resourceType, namespace, name);
  const trigger = useRef<HTMLButtonElement>(null);
  const pending = useRef<AbortController>();
  const allowed = useRef(session.canWrite);
  allowed.current = session.canWrite;
  const identity = useRef(base);
  identity.current = base;
  const owns = (signal: AbortSignal) => allowed.current && identity.current === base && !signal.aborted && pending.current?.signal === signal;
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [yaml, setYaml] = useState<{ value: string; edit: boolean }>();
  const [logs, setLogs] = useState<{ containers: string[]; container: string; value?: string; error?: string }>();
  const [confirmation, setConfirmation] = useState<Confirmation>();
  const returnFocus = () => trigger.current?.focus();
  useEffect(() => {
    allowed.current = session.canWrite;
    return () => { allowed.current = false; pending.current?.abort(); if (timer.current) clearTimeout(timer.current); };
  }, [session.canWrite, base]);
  useEffect(() => {
    pending.current?.abort();
    pending.current = undefined;
    setYaml(undefined); setLogs(undefined); setConfirmation(undefined);
    setBusy(false); setMessage("");
    if (timer.current) clearTimeout(timer.current);
  }, [session.canWrite, base]);
  const notify = (text: string) => {
    setMessage(text); if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(""), 6000);
  };
  const load = async (task: (signal: AbortSignal) => Promise<void>, propagateError = false) => {
    if (!allowed.current || identity.current !== base) return;
    pending.current?.abort();
    const controller = new AbortController();
    pending.current = controller;
    setBusy(true);
    try { await task(controller.signal); }
    catch (error) {
      if (owns(controller.signal)) {
        if (propagateError) throw error;
        notify(error instanceof Error ? error.message : "Request failed");
      }
    }
    finally { if (owns(controller.signal)) { pending.current = undefined; setBusy(false); } }
  };
  const showYaml = (edit: boolean) => load(async signal => {
    const data = await requestJson<{ yaml: string }>(base + "/yaml", { signal });
    if (owns(signal)) setYaml({ value: data.yaml, edit });
  });
  const download = () => load(async signal => {
    const data = await requestJson<{ yaml: string }>(base + "/yaml", { signal });
    if (!owns(signal)) return;
    const url = URL.createObjectURL(new Blob([data.yaml], { type: "application/yaml" }));
    const anchor = document.createElement("a"); anchor.href = url;
    anchor.download = `${resourceType}-${namespace ? namespace + "-" : ""}${name}.yaml`;
    anchor.click(); URL.revokeObjectURL(url);
  });
  const readLogs = async (container: string, containers: string[], signal: AbortSignal) => {
    setLogs({ containers, container });
    try {
      const query = new URLSearchParams({ tail: "100", container });
      const data = await requestJson<{ logs: string }>(base + "/logs?" + query, { signal });
      if (owns(signal)) setLogs({ containers, container, value: data.logs });
    } catch (error) {
      if (owns(signal)) setLogs({ containers, container, error: error instanceof Error ? error.message : "Log request failed" });
      throw error;
    }
  };
  const showLogs = () => load(async signal => {
    // List rows deliberately omit container details; use the existing redacted
    // Pod metadata endpoint rather than letting kubectl choose a sidecar.
    const pod = resource.spec?.containers ? resource : (await requestJson<{ pod: Resource }>(base, { signal })).pod;
    if (!owns(signal)) return;
    const containers = [...new Set([...(pod.spec?.containers ?? []), ...(pod.spec?.initContainers ?? []), ...(pod.spec?.ephemeralContainers ?? [])]
      .map(container => container.name).filter((name): name is string => typeof name === "string" && name.length > 0))];
    setLogs({ containers, container: "" });
    if (containers.length === 1) await readLogs(containers[0], containers, signal);
  });
  const selectLogContainer = (container: string) => {
    if (!logs?.containers.includes(container)) return;
    void load(signal => readLogs(container, logs.containers, signal));
  };
  const closeLogs = () => { pending.current?.abort(); pending.current = undefined; setLogs(undefined); setBusy(false); };
  const changed = () => { refetchCluster(); onAction?.(); };
  const mutate = async (signal: AbortSignal, url: string, method: string, body?: unknown) => {
    if (!owns(signal)) return;
    await requestJson(url, { signal, method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
    if (owns(signal)) changed();
  };
  const action = (actionName: string, body?: unknown) => load(async signal => {
    try { await mutate(signal, base + (actionName === "scale" ? "/scale" : "/action"), "POST", body ?? { action: actionName }); if (owns(signal)) notify("Action accepted. Refreshing resource state."); }
    finally { if (resourceType === "node" && owns(signal)) changed(); }
  });
  const confirm = (title: string, message: string, label: string, execute: (signal: AbortSignal) => Promise<void>, exactName?: string) => {
    setMessage(""); setConfirmation({ title, message, label, execute, name: exactName });
  };
  const finishConfirmation = async () => {
    if (!confirmation || busy) return;
    await load(async signal => {
      await confirmation.execute(signal);
      if (owns(signal)) { setConfirmation(undefined); notify("Action accepted. Refreshing resource state."); }
    });
  };
  const items: { label: string; run: () => void; danger?: boolean; disabled?: boolean }[] = session.canWrite ? [
    { label: "View YAML", run: () => { void showYaml(false); } },
    { label: "Download YAML", run: () => { void download(); } },
  ] : [];
  if (session.canWrite && capability.logs) items.unshift({ label: "View Logs", run: () => { void showLogs(); } });
  if (session.canWrite) {
    if (capability.yamlEdit) items.push({ label: "Edit YAML", run: () => { void showYaml(true); } });
    if (resourceType === "pod" && session.data?.capabilities?.podExec) items.push({ label: "Execute Shell", run: () => { openShell("exec", namespace, name, trigger.current); } });
    if (resourceType === "deployment") {
      const replicas = resource.spec?.replicas ?? resource.desiredReplicas ?? resource.replicas ?? 1;
      const paused = resource.spec?.paused ?? resource.paused ?? false;
      items.push(
        { label: "Restart", run: () => { void action("restart"); } },
        { label: "Rollback", run: () => confirm("Roll back deployment", "Flux may restore Git desired state after this runtime operation.", "Roll back", signal => mutate(signal, base + "/action", "POST", { action: "rollback" })) },
        { label: "Scale Up", disabled: paused || !Number.isInteger(replicas) || replicas >= 10000, run: () => { void action("scale", { replicas: replicas + 1 }); } },
        { label: "Scale Down", disabled: paused || !Number.isInteger(replicas) || replicas <= 0, run: () => { void action("scale", { replicas: replicas - 1 }); } },
        { label: paused ? "Resume" : "Pause", run: () => { void action(paused ? "resume" : "pause"); } },
      );
    }
    if (resourceType === "node") {
      const cordoned = resource.spec?.unschedulable ?? false;
      items.push({ label: cordoned ? "Uncordon" : "Cordon", run: () => { void action(cordoned ? "uncordon" : "cordon"); } },
        { label: "Drain", danger: true, run: () => confirm("Drain node", "Evicts managed pods while respecting disruption budgets. Refuses unmanaged pods and local data. A failure or timeout can leave the node cordoned or partially drained; inspect it before retrying.", "Drain", async signal => {
          try { await mutate(signal, base + "/action", "POST", { action: "drain", confirmName: name }); } finally { if (owns(signal)) changed(); }
        }, name) });
    }
    if (capability.delete) items.push({ label: "Delete", danger: true, run: () => confirm(`Delete ${capability.kind}`,
      `Delete ${namespace ? namespace + "/" : ""}${name}? Controllers or Flux may recreate it. Inspect dependent resources before deleting.`, "Delete",
      signal => mutate(signal, base + "/delete", "DELETE"), name) });
  }
  return <>
    <DropdownMenu.Root defaultOpen={initialOpen}>
      <DropdownMenu.Trigger asChild><button ref={trigger} disabled={busy} aria-label={`Actions for ${name}`} className="rounded-lg p-2 hover:bg-zinc-800 disabled:opacity-50"><MoreHorizontal className="h-5 w-5" /></button></DropdownMenu.Trigger>
      <DropdownMenu.Portal><DropdownMenu.Content align="end" sideOffset={4} className="z-40 min-w-[180px] rounded-lg border border-zinc-700 bg-zinc-900 p-1 shadow-xl">
        {items.map(item => <DropdownMenu.Item key={item.label} disabled={item.disabled}
          onSelect={item.run} className={`cursor-pointer rounded px-3 py-2 text-sm outline-none focus:bg-zinc-800 data-[disabled]:opacity-40 ${item.danger ? "text-red-300" : "text-zinc-200"}`}>{item.label}</DropdownMenu.Item>)}
      </DropdownMenu.Content></DropdownMenu.Portal>
    </DropdownMenu.Root>
    {(message || busy) && <p role="status" className="fixed bottom-4 right-4 z-[70] max-w-[calc(100vw-2rem)] rounded-lg border border-zinc-700 bg-zinc-900 p-3 text-sm">{busy ? "Working…" : message}</p>}
    {session.canWrite && yaml && <YamlModal open onClose={() => setYaml(undefined)} yaml={yaml.value} title={`${capability.kind} YAML: ${namespace ? namespace + "/" : ""}${name}`}
      readOnly={!yaml.edit || !session.canWrite || !capability.yamlEdit} returnFocus={returnFocus}
      onSave={yaml.edit && session.canWrite && capability.yamlEdit ? value => load(async signal => { await mutate(signal, base + "/yaml", "PUT", { yaml: value }); if (owns(signal)) notify("YAML replaced. Refreshing resource state."); }, true) : undefined} />}
    {session.canWrite && logs !== undefined && <LogModal open onClose={closeLogs} logs={logs.value} containers={logs.containers}
      container={logs.container} onContainerChange={selectLogContainer} loading={busy} error={logs.error}
      title={`Logs: ${namespace}/${name}`} returnFocus={returnFocus} />}
    {session.canWrite && confirmation && <ConfirmDialog open onClose={() => { if (!busy) setConfirmation(undefined); }} title={confirmation.title}
      message={confirmation.message} confirmLabel={confirmation.label} confirmName={confirmation.name} error={message} danger loading={busy} onConfirm={finishConfirmation} returnFocus={returnFocus} />}
  </>;
}
